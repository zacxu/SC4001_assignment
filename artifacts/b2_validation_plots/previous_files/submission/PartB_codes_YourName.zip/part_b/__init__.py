"""Part B assignment code."""
