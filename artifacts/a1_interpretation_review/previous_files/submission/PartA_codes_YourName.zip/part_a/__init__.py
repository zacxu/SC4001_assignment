"""Part A assignment code."""
